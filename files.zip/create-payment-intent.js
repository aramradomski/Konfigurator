// Netlify Function: /netlify/functions/create-payment-intent
// Erstellt einen Stripe Payment Intent serverseitig
// Secret Key kommt aus Netlify Environment Variable STRIPE_SECRET_KEY

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async function(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const data = JSON.parse(event.body);
    const { amount, currency, orderId, customerEmail, description } = data;

    if (!amount || amount < 50) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Ungültiger Betrag' }) };
    }

    const intent = await stripe.paymentIntents.create({
      amount:             Math.round(amount * 100), // Stripe nimmt Cents
      currency:           currency || 'eur',
      description:        description || 'Berlintapete Bestellung',
      receipt_email:      customerEmail || undefined,
      metadata:           { orderId: orderId || '' },
      automatic_payment_methods: { enabled: true },
    });

    return {
      statusCode: 200,
      headers:    { 'Content-Type': 'application/json' },
      body:       JSON.stringify({ clientSecret: intent.client_secret })
    };
  } catch (err) {
    console.error('Stripe Error:', err.message);
    return {
      statusCode: 500,
      headers:    { 'Content-Type': 'application/json' },
      body:       JSON.stringify({ error: err.message })
    };
  }
};
